GAME BALAP JALANAN OFFLINE - ANDROID APK

Game berjalan tanpa internet setelah diinstal. Kontrol menggunakan tombol kiri/kanan.
Rekor terbaik disimpan di perangkat.

CARA MEMBUAT APK DARI HP ANDROID (GitHub Actions):
1. Ekstrak ZIP ini.
2. Unggah semua ISI folder proyek ke repository GitHub baru atau repository milik Anda.
   Pastikan file .github/workflows/android.yml ikut terunggah.
3. Buka repository > tab Actions.
4. Pilih workflow "Build Android APK", lalu tekan Run workflow jika belum berjalan otomatis.
5. Setelah proses hijau/selesai, buka hasil workflow > Artifacts > download "balap-jalanan-apk".
6. Ekstrak file ZIP hasil artifact, lalu buka app-debug.apk di HP untuk menginstal.
   Android mungkin meminta izin "Install unknown apps" untuk aplikasi/browser yang dipakai.

Catatan:
- Ini adalah proyek sumber, bukan APK siap instal; APK dibangun oleh GitHub Actions.
- Tidak membutuhkan server milik sendiri.
- Jangan menghapus folder .github/workflows saat mengunggah.
